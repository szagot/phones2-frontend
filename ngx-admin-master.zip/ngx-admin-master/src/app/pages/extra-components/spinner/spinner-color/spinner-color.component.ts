import { Component } from '@angular/core';

@Component({
  selector: 'ngx-spinner-color',
  templateUrl: 'spinner-color.component.html',
})

export class SpinnerColorComponent {
}
